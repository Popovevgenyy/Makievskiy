﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PopovZachet.DataBase;

namespace PopovZachet.Properties
{
	/// <summary>
	/// Логика взаимодействия для AddStudents.xaml
	/// </summary>
	public partial class Studentas : Page
	{
		public Studentas()
		{
			InitializeComponent();
			Specialn.SelectedValuePath = "id";
			Specialn.DisplayMemberPath = "Name";
			Specialn.ItemsSource = BigData.bazaDannix.Curs.ToList();
			FormaOb.SelectedValuePath = "id";
			FormaOb.DisplayMemberPath = "Name";
			FormaOb.ItemsSource = BigData.bazaDannix.FormaObuch.ToList();
			GroupName.SelectedValuePath = "id";
			GroupName.DisplayMemberPath = "Name";
			GroupName.ItemsSource = BigData.bazaDannix.Group.ToList();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Student student = new Student()
				{
					Name = Familya.Text,
					IdGroup = (int)GroupName.SelectedValue,
					IdFormaObuch = (int)FormaOb.SelectedValue,
					GodPostupleniya = Convert.ToInt32 (GodPostupa.Text),
					IdCurs = (int)Specialn.SelectedValue,
				};
				BigData.bazaDannix.Student.Add(student);
				BigData.bazaDannix.SaveChanges();
				MessageBox.Show("Студент добавлен","Поздравляю!",MessageBoxButton.OK);

			}
			catch (Exception )
			{

				throw;
			}

		}
	}
}
