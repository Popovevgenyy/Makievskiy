﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PopovZachet.DataBase;

namespace PopovZachet.Properties
{
	/// <summary>
	/// Логика взаимодействия для Mark.xaml
	/// </summary>
	public partial class Osenki : Page
	{
		public Osenki()
		{
			InitializeComponent();
			TeamGroup.SelectedValuePath = "id";
			TeamGroup.DisplayMemberPath = "Name";
			TeamGroup.ItemsSource = BigData.bazaDannix.Group.ToList();

			TeamStudent.SelectedValuePath = "id";
			TeamStudent.DisplayMemberPath = "Name";
			TeamStudent.ItemsSource = BigData.bazaDannix.Student.ToList();

			Predmet.SelectedValuePath = "id";
			Predmet.DisplayMemberPath = "Name";
			Predmet.ItemsSource = BigData.bazaDannix.Disceplina.ToList();

		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Jurnal jurnal = new Jurnal()
				{
					IdStudent = (int)TeamStudent.SelectedValue,
					IdDisceplina = (int)Predmet.SelectedValue,
					Otmetka = Convert.ToInt32(Ocenka.Text),

				};
				BigData.bazaDannix.Jurnal.Add(jurnal);
				BigData.bazaDannix.SaveChanges();
				MessageBox.Show("Оценка студенту поставлена","Поздравляю!",MessageBoxButton.OK);

			}
			catch (Exception )
			{

				throw;
			}
		}

        private void CBStudent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
