﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;


namespace Prakt._5
{
    class FrameClass
    {
        public static Frame evgeniy; 
    }
}
