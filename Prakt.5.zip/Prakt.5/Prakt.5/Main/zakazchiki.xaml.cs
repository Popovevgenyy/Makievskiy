﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Prakt._5.MegaBase;

namespace Prakt._5.Main
{
    /// <summary>
    /// Логика взаимодействия для zakazchiki.xaml
    /// </summary>
    public partial class zakazchiki : Page
    {
        public static int IDZakaz { get; set; }
        public static int IDVoditel { get; set; }
        public zakazchiki()
        {
            InitializeComponent();
            evg.ItemsSource = Baza.dannie.AutoTrailer.ToList();
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int delIdTrailer, delIdZakaz; 
                dynamic row = evg.SelectedItem; 
                delIdTrailer = row.id;
                delIdZakaz = row.id;
                var del = Baza.dannie.AutoTrailer.FirstOrDefault(x => x.id == delIdTrailer);
                var dEl = Baza.dannie.Zakaz.FirstOrDefault(x => x.id == delIdZakaz);
                Baza.dannie.AutoTrailer.Remove(del);
                Baza.dannie.Zakaz.Remove(dEl);
                Baza.dannie.SaveChanges();
                MessageBox.Show("Удалено");
                evg.ItemsSource = Baza.dannie.AutoTrailer.ToList(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            FrameClass.evgeniy.Navigate(new dobavit());
        }     
private void BtnIzm_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic row = evg.SelectedItem;
                IDZakaz = row;
                IDVoditel = row.Id;
                FrameClass.evgeniy.Navigate(new dobavit());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}