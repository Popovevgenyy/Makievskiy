﻿using Prakt._5.MegaBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prakt._5.Main
{
    /// <summary>
    /// Логика взаимодействия для dobavit.xaml
    /// </summary>
    public partial class dobavit : Page
    {
        public dobavit()
        {
            InitializeComponent();
            CmbDriver.ItemsSource = Baza.dannie.Voditel.Select (x => x.Name).ToList();
        }

        private int CheckTrailer()
        {
            Random Ran = new Random();
            List<int> glist = new List<int>();
            foreach (var voditel in Baza.dannie.Voditel.Select(x => x.id))
            {
                glist.Add(voditel);
            }
            int IdTrailer = Ran.Next(glist.Count);
            glist.Clear();
            return IdTrailer;

        }

        private void BtnChange_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Zakaz add = new Zakaz()
                {
                    Name = TxbName.Text,
                    PointOfDeparture = TxbA.Text,
                    PointOfDestination = TxbB.Text,
                    Distance = (TxbDistanse.Text),
                    Ves = int.Parse(TxbWeight.Text),
                };

                AutoTrailer autoTrailer = new AutoTrailer()
                {
                    IdTrailer = CheckTrailer(),
                    IdVoditel = Baza.dannie.Voditel.FirstOrDefault(x => x.Name == CmbDriver.SelectedItem.ToString()).id, 
                    IdZakaz = add.id,
                };
                var check = Baza.dannie.Zakaz.FirstOrDefault(x => x.Name == TxbName.Text); 
                if (check == null)
                {
                    Baza.dannie.Zakaz.Add(add);
                    Baza.dannie.AutoTrailer.Add(autoTrailer);
                    Baza.dannie.SaveChanges();
                    MessageBox.Show("Готово");
                    FrameClass.evgeniy.Navigate(new dobavit());
                }
                else
                    MessageBox.Show("Не корректно заполнелы поля");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ОШИБКА");
            }
        }
    }
}
