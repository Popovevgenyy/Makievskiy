﻿using System;
using Prakt._5.MegaBase;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prakt._5
{
    class Baza
    {
        public static PopovEntities dannie;
    }
}
